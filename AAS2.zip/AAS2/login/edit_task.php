<?php
include('../include/connection.php');
if(isset($_POST['edit_task'])){
    $query = "UPDATE task 
          SET uid='{$_POST['uid']}',
              description='{$_POST['description']}',
              start_date='{$_POST['start_date']}',
              end_date='{$_POST['end_date']}'
          WHERE tid = '{$_GET['id']}'";
    $query_run=mysqli_query($connection,$query);
    if($query_run){
        echo"<script type='text/javascript'>
            alert('Update successfully..');
            window.location.href='admin_page.php';
            </script>";
    }
    else{
        echo"<script type='text/javascript'>
        alert('Error..Please try again... ');
        window.location.href='admin_task.php';
        </script>";

    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="styles.css">
<script type="text/javascript">
 
</script>
    <title>Edit Task</title>
</head>
<body>
        <header class="nav" id="navbar">
           <div class="logo">
           <p>AssignAlert</p>
           </div>
             
           <div class="search-container">
        <input type="text" class="search-bar" placeholder="Search...">
        <i class="fa fa-search" aria-hidden="true"></i>
    </div>
            <nav>
                <ul class="nav__links">
                    <li><a href="createtask.php" id="createtask"><i class="fa fa-plus-circle" aria-hidden="true"></i>Add Task</a></li>
                    
                    <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Calender</a></li>

                    <li><a href="#"><i class="fa fa-bars" aria-hidden="true"></i></a></li>
                </ul>
            </nav>
           
        </header>
    <div class="side-nav">
    <ul class="sidebar">
                    <li><a href="admin_page.php"><i class="fa fa-home" aria-hidden="true"><p>Home</p></i></a></li>
                    <li><a href="managetask.php"><i class="fa fa-inbox" aria-hidden="true"><p>Inbox</p></i></a></li>
                    <li  style="text-align: center;"><a href="appl.php"><i class="fa fa-file-text-o" aria-hidden="true"> <p>Application</p></i></a></li>
                    
                    
              
                <li><a href="invite.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <p>Invite</p></a></li>
                    <li><a href="logout.php"><i  class="fa fa-sign-out"  aria-hidden="true"></i><p>Logout</p></a></li>
                </ul>
    </div>
   <div class="rightsidebar">
        <div class="createright">
        
                    <div class="col-md-4 ">
                        <h2>Edit Task</h2>
                        <?php
                        include('../include/connection.php');
                         $query = "select * from task where tid=$_GET[id]";
                        $query_run = mysqli_query($connection,$query);
                        while($row=mysqli_fetch_assoc($query_run)){
                            ?>
                       
                        <form action=""method="post">
                            <div class="from-group">
                                <input type="hidden" name="id"class="from-control"value=""requried>
                            </div>
                            <div class="from-group">
                            <br><label for=""><h5>Select User:</h5></label>
                            <select class="form-control" name="uid" required>
    <option value="">-Select User-</option>
    <?php
    include('../include/connection.php');
    $query1 = "SELECT id, name FROM user_form WHERE user_type = 'user'";
    $query_run1 = mysqli_query($connection, $query1);
    if(mysqli_num_rows($query_run1)){
        while($row1 = mysqli_fetch_assoc($query_run1)){
            ?>
            <option value="<?php echo $row1['id']; ?>"><?php echo $row1['name']; ?></option>
            <?php
        }
    }
    ?>
</select>

                            </div>
                            <div class="from-group">
                                <label for="">Description:</label>
                                <textarea name="description" id=""  cols="140" rows="10 class="form-control" placeholder="Mention the task" required><?php echo $row['description']; ?> 

                            </textarea>
                            </div>
                            </div>
                        <div class="form-group">
                        <br><label for=""><h5>Upload File:</h5></label><br>
                        <form action="upload.php" method="POST" enctype="multipart/form-data">
			<div class="mb-3">
				<label for="file" class="form-label">Select file</label>
				<input type="file" class="form-control" name="file" id = "file">
			</div>
			<button type="submit" class="btn btn-primary">Upload file</button>
		
                            </div>
                            <div class="from-group">
                            <br><label for=""><h5>Start Date:</h5></label>
                            <input type="date" class="from-control"name="start_date" value="<?php echo$row['start_date'];?>" required>
                        </div>
                        <div class="from-group">
                            <br><label for=""><h5>End Date</h5></label>
                            <input type="date" class="from-control"name="end_date" value="<?php echo$row['end_date'];?>" required>
                        </div><br>
                        <input type="submit" class="btn btn-warning" name="edit_task" value="Update">
                        </form>
                           <?php }
                           ?>                    </div>
                </div>
    </div>

   
    
    
       
</body>
</html> 
<?php
@include 'config.php';
session_start();
include('../include/connection.php');

if(isset($_POST["create_task"])){
    $id = $_POST["id"];
    $description = $_POST["description"];
    $start_date = $_POST["start_date"];
    $end_date = $_POST["end_date"];
    
    $query="INSERT INTO task (uid, description, start_date, end_date, status) VALUES ('$id','$description','$start_date','$end_date','Not Started')";
    $query_run=mysqli_query($connection,$query);
    if($query_run){
        echo"<script type='text/javascript'>
            alert('Task created successfully..');
            window.location.href='admin_page.php';
            </script>";
    }
    else{
        echo"<script type='text/javascript'>
        alert('Error..Please try again... ');
        window.location.href='create_task.php';
        </script>";

    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="styles.css">
<script type="text/javascript">
 
</script>
    <title>Add Task</title>
</head>
<body>
        <header class="nav" id="navbar">
           <div class="logo">
           <p>AssignAlert</p>
           </div>
             
           <div class="search-container">
        <input type="text" class="search-bar" placeholder="Search...">
        <i class="fa fa-search" aria-hidden="true"></i>
    </div>
            <nav>
                <ul class="nav__links">
                    <li><a href="createtask.php" id="createtask"><i class="fa fa-plus-circle" aria-hidden="true"></i>Add Task</a></li>
                    
                    <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Calender</a></li>

                    <li> <a>UserName:<?php echo $_SESSION['admin_name'] ?></a></li>
                </ul>
            </nav>
           
        </header>
    <div class="side-nav">
    <ul class="sidebar">
                    <li><a href="admin_page.php"><i class="fa fa-home" aria-hidden="true"><p>Home</p></i></a></li>
                    <li><a href="managetask.php"><i class="fa fa-inbox" aria-hidden="true"><p>Inbox</p></i></a></li>
                    <li  style="text-align: center;"><a href="appl.php"><i class="fa fa-file-text-o" aria-hidden="true"> <p>Application</p></i></a></li>
           
                    
              
                <li><a href="invite.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <p>Invite</p></a></li>
                    <li><a href="logout.php"><i  class="fa fa-sign-out"  aria-hidden="true"></i><p>Logout</p></a></li>
                </ul>
    </div>
   <div class="rightsidebar">
        <div class="createright">
          <div class="col-mod-1">
            <h2>Add New Task</h2>
            <div class="col-mod-2">
            <form action="upload.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Select User</label>
                    <select class="form-control" name="id">
                        <option>-Select User-</option>
                        <?php
                        include('../include/connection.php');
                        @include 'config.php';
                        $query = "SELECT id, name FROM user_form WHERE user_type = 'user'";
                        $query_run = mysqli_query($connection, $query);
                        if (mysqli_num_rows($query_run)) {
                            while ($row = mysqli_fetch_assoc($query_run)) {
                                ?>
                                <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Description:</label>
                    <textarea name="description" cols="140" rows="10" class="form-control" placeholder="Mention the task"></textarea>
                </div>
               
                <div class="form-group">
                    <label for=""><h5>Start Date:</h5></label>
                    <input type="date" class="form-control" name="start_date">
                </div>
                <div class="form-group">
                    <label for=""><h5>End Date</h5></label>
                    <input type="date" class="form-control" name="end_date">
                </div>
                
                <label for="file" class="form-label"><h5>Select file</h5></label>

        <input type="file" class="form-control" name="file" id="file">
        <br>
        <button type="submit" class="btn btn-warning">Create</button>
   
                
             </form>   
            </div>
          </div>
        </div>    
        
   </div>
   </div>
   </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
  <title>Assign Alert</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="front.css">
</head>
<body>

    <header>
   
      </div>
        <div class="header-content">
 
           <!-- Navigation links -->
         <div class="bottom">
          <nav class="navigation-links">
            <ul>
                <li><a href="login_form.php">Home</a></li>
                <li><a href="#about-us">About Us</a></li>
            
            </ul>
        </nav>
      </div>
          
      <!-- background image -->
           

          <div class="heading">
            <h1>Welcome to  Assign<span>Alert</span> </h1>
            <p class="slogan">"Revolutionizing Task Management and Collaboration"</p>
          </div>

          <div class="logo">
            <img src="alert.jpg" alt="Assign Alert Logo">
          </div>
       

        
          <a href="login_form.php" class="btn">Start</a>
      </div>   
      </header>
    
  
  <section class="about-us">
    <h2>About Us</h2>

    

    
    <div class="team-members">
      <div class="team-member">
        <img src="shubham Sharma.jpg" alt="Team Member 1">
        <p><h3><b>Shubham Sharma</b></h3></p>
      </div>
      <div class="team-member">
        <img src="Untitled design.jpg" alt="Team Member 2">
        <p><h3><b>Vishal Varma</b></h3></p>
      </div>
      <div class="team-member">
        <img src="anurag2.0.png" alt="Team Member 3">
        <p><h3><b>Anurag Yadav</b></h3></p>
      </div>
      <div class="team-member">
        <img src="Rakesh yadav.jpg" alt="Team Member 4">
        <p><h3><b>Rakesh Yadav</b></h3></p>
      </div>
    </div>
  </section>

  <!-- Other sections or content can be added here -->

  <footer>
    
    <p><h3>  Copyrights © 2024 - all rights are reserved</h3></p>
    <!-- Footer content -->
  </footer>
</body>
</html>


<?php 
  include('../include/connection.php');
  $name = mysqli_real_escape_string($connection,$_POST['name']);
  $email = mysqli_real_escape_string($connection,$_POST['email']);
  $password = mysqli_real_escape_string($connection,$_POST['password']);
 
  if(!empty($name) && !empty($email) && !empty($password)){
    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
        $sql= mysqli_query($connection,"SELECT * FROM user_form WHERE email='{$email}'");
    if(mysqli_num_rows($sql)>0){
        echo " $email - This email already exist!";
    }
    else{
         if(isset($_FILES['image'])){
            $img_name = $_FILES['image']['name'];
            $img_explode = explode('.',$img_name);
            $img_ext = end($img_explode);
        $extensions=["jpeg","png","jpg"];
        if(in_array($img_ext,$extensions)=== true){
         $type = ["image/jpg","image/png","image/jpeg"];
         if(in_array($img_type,$type)=== true){
            $time =time();
            $new_img_name = $time.$img_name;
            if(move_uploaded_file($tmp_name,"images/".$new_img_name)){
             $ran_id = rand(time(),100000000);
             $chatstatus= "Online";
             $encrypt_passs = md5($password);

             $insert_query = mysqli_query($connection,"INSERT INTO user_form(id, name, email, password, chatstatus,img)VALUES({ran_id},'{name}','{email}','{password}','{chatstatus}')");
             
            }else{
                echo "Something went wrong please try again";
            }
         }
        }else{
            echo"Please Upload an Image file- jpg,png,jpeg";
        }
         }
    }
    }
    else{
        echo "$email is not a valid email!";
    }
  }
  else{
    echo "All input fields are required!";
  }
?>
 if(mysqli_num_rows($sql)>0){
                    $row = mysqli_fetch_assoc($sql);
                }
                <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="styles.css">
<link rel="stylesheet" type="text/css" href="initial.css">
<script type="text/javascript">
 
</script>
<style>
 

</style>
    <title>Admin Dashboard</title>
</head>
<body>
        <header class="nav" id="navbar">
           <div class="logo">
           <p>AssignAlert</p>
           </div>
             
           <div class="search-container">
        <input type="text" class="search-bar" placeholder="Search...">
        <i class="fa fa-search" aria-hidden="true"></i>
    </div>
            <nav>
                <ul class="nav__links">
                    <li><a href="createtask.php" id="createtask"><i class="fa fa-plus-circle" aria-hidden="true"></i>Add Task</a></li>
                    
                    <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Calander</a></li>

                    <li><a href="#"><i class="fa fa-bars" aria-hidden="true"></i></a></li>
                </ul>
            </nav>
           
        </header>
    <div class="side-nav">
    <ul class="sidebar">
                    <li><a href="admin_dashboard.php"><i class="fa fa-home" aria-hidden="true"><p>Home</p></i></a></li>
                    <li><a href="managetask.php"><i class="fa fa-inbox" aria-hidden="true"><p>Inbox</p></i></a></li>
                    <li><a href="#"><i class="fa fa-file-text-o" aria-hidden="true"> <p>Docs</p></i></a></li>
                    <li><a href="more.php"><i class="fa fa-ellipsis-h" aria-hidden="true"> <p>More</p></i></a></li>
                    
              
                <li><a href="invite.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <p>Invite</p></a></li>
                    <li><a href="../logout.php"><i class="fa fa-question-circle-o" aria-hidden="true"></i><p>Logout</p></a></li>
                </ul>
    </div>
    <div class="rightsidebar">
    <div class="pvwin">
             <div class="header1">
            
                <div class="dashboard1">
                <i class="fa fa-gauge" aria-hidden="true"></i> <h3> Dashboard</h3> 
            
                </div>
               
             


                
            </div>

  
   
            <div class="main-content">

                <div class="box1">Recent
                    <div class="text">
                        
                        <i class="fa-solid fa-2x fa-square-poll-vertical"></i>
                        Your recently opened Dashboards will show here
                     </div>
                </div>

                <div class="box2">Favorites
                    <div class="text">
                        
                        <i class="fa-solid fa-2x fa-square-poll-vertical"></i>
                       Your Favorite Dashboards will show here 
                    </div>
                </div>
                
                <div class="box3">Created by me
                    <div class="text">
                        
                        <i class="fa-solid fa-2x fa-square-poll-vertical"></i>
                        All Dashboards created by me will show here 
                    </div>
                </div>
            </div>
                
            <div class="second-panel">
                <div class="panel-ops">
                <a href="managetask.php"type="button"class="btn btn-warning"style="text-decoration:none;color:black;">All</a> 

                    <a href="#"type="button"class="btn btn-warning"style="text-decoration:none;color:black;">Application</a> 

                    
                    


              </div>
                <div class="panel-search">
                    <input type="text" class="search-panel" placeholder="Search.... ">
        
                </div>
        </div>
   
    </div>
</div>
    
       
</body>
</html> 
$sql = "INSERT INTO task (uid, description, start_date, end_date, status, filename, filesize, filetype) VALUES ('$user_id', '$description', '$start_date', '$end_date', 'Not Started', '$filename', $filesize, '$filetype')";
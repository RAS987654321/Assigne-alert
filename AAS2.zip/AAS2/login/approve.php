<?php
@include 'config.php';
    include('../include/connection.php');
    $query = "UPDATE leaves SET astatus = 'Approved' WHERE lid = $_GET[id]";
    $query_run= mysqli_query($connection,$query);
    if($query_run){
        echo"<script type='text/javascript'>
        alert('Task created successfully..');
        window.location.href='appl.php';
        </script>";
    }
    else{
        echo"<script type='text/javascript'>
        alert('Error..Please try again... ');
        window.location.href='admin_page.php';
        </script>";

    }
?>
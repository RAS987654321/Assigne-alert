<?php
include('../include/connection.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM leaves WHERE lid = '{$id}'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) {
        echo "<script type='text/javascript'>
            alert('Deleted successfully..');
            window.location.href='user_page.php';
            </script>";
    } else {
        echo "<script type='text/javascript'>
        alert('Error..Please try again... ');
        window.location.href='notification.php';
        </script>";
    }
} else {
    echo "ID not provided.";
}
?>

<?php

$conn = mysqli_connect('localhost','root','','aas_db');

?>
<?php
include('../include/connection.php');
if(isset($_POST['update'])){
    $query = "UPDATE task 
          SET status='$_POST[status]'
          WHERE tid = '{$_GET['id']}'";
    $query_run=mysqli_query($connection,$query);
    if($query_run){
        echo"<script type='text/javascript'>
            alert(' Status Update successfully..');
            window.location.href='user_page.php';
            </script>";
    }
    else{
        echo"<script type='text/javascript'>
        alert('Error..Please try again... ');
        window.location.href='task.php';
        </script>";

    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="styles.css">
<script type="text/javascript">
 
</script>
    <title>Update Task</title>
</head>
<body>
        <header class="nav" id="navbar">
           <div class="logo">
           <p>AssignAlert</p>
           </div>
             
           <div class="search-container">
        <input type="text" class="search-bar" placeholder="Search...">
        <i class="fa fa-search" aria-hidden="true"></i>
    </div>
            <nav>
                <ul class="nav__links">
                    <li><a href="createtask.php" id="createtask"><i class="fa fa-plus-circle" aria-hidden="true"></i>Add Task</a></li>
                    
                    <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Calander</a></li>

                 
                </ul>
            </nav>
           
        </header>
    <div class="side-nav">
    <ul class="sidebar">
                    <li><a href="admin_page.php"><i class="fa fa-home" aria-hidden="true"><p>Home</p></i></a></li>
                    <li><a href="task.php"><i class="fa fa-inbox" aria-hidden="true"><p>Inbox</p></i></a></li>
                    <li  style="text-align: center;"><a href="application.php"><i class="fa fa-file-text-o" aria-hidden="true"> <p>Application</p></i></a></li>
                    
                    
              
                <li><a href="invite.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <p>Invite</p></a></li>
                    <li><a href="logout.php"><i  class="fa fa-sign-out"  aria-hidden="true"></i><p>Logout</p></a></li>
                </ul>
    </div>
    <div class="rightsidebar">
        <div class="createright">
        
                    <div class="col-md-4 ">
                        <h2>Update Task</h2>
                        <?php
                        include('../include/connection.php');
                         $query = "select * from task where tid=$_GET[id]";
                        $query_run = mysqli_query($connection,$query);
                        while($row=mysqli_fetch_assoc($query_run)){
                            ?>
                       
                        <form action=""method="post">
                            <div class="from-group">
                                <input type="hidden" name="id"class="from-control"value=""requried>
                            </div>
                            <div class="from-group">
                            
                            <select class="form-control" name="status" required>
    <option value="">-Select-</option>
    <option value="In-Progress">In-Progress</option>
    <option value="Completed">Completed</option>
</select>


                            </div>
                           <br>
                        <input type="submit" class="btn btn-warning" name="update" value="Update">
                        </form>
                           <?php }
                           ?>                    </div>
                </div>
    </div>

   
    
    
       
</body>
</html> 
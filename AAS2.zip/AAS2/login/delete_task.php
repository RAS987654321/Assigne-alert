<?php
include('../include/connection.php');

    $query = "DELETE  FROM task  WHERE tid = '{$_GET['id']}'";
    $query_run=mysqli_query($connection,$query);
    if($query_run){
        echo"<script type='text/javascript'>
            alert('Update successfully..');
            window.location.href='admin_page.php';
            </script>";
    }
    else{
        echo"<script type='text/javascript'>
        alert('Error..Please try again... ');
        window.location.href='admin_task.php';
        </script>";

    }

?>

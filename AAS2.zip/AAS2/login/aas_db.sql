-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 06:09 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aas_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `mobile` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `mobile`) VALUES
(1, 'shubham', 'shubhamsharma68653@gmail.com', 'Abcd@123', 9309944294);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `filesize` int(11) NOT NULL,
  `filetype` varchar(100) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `filename`, `filesize`, `filetype`, `upload_date`) VALUES
(1, 'AssignAlertlogo1.png', 94150, 'image/png', '2024-03-29 12:07:57'),
(11, 'AssignAlertlogo1.png', 94150, 'image/png', '2024-03-29 12:03:33'),
(12, 'AssignAlertlogo1.png', 94150, 'image/png', '2024-03-29 12:22:56');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `lid` int(225) NOT NULL,
  `id` int(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `message` varchar(225) NOT NULL,
  `astatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`lid`, `id`, `name`, `subject`, `message`, `astatus`) VALUES
(7, 8, 'Anurag', 'Apply For Home', 'ewnjfjknkjwefjnfkjfnkwenkfjnkwe', 'Approved'),
(8, 8, 'Anurag', 'Apply For Home', 'huhuh8h8h', 'Approved'),
(9, 8, 'Anurag', 'Apply For Home', 'fewuutdeu', 'No Action');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `incoming_msg_id` varchar(225) DEFAULT NULL,
  `outgoing_msg_id` varchar(225) DEFAULT NULL,
  `msg` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `filename` varchar(225) NOT NULL,
  `filesize` int(11) NOT NULL,
  `filetype` varchar(225) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`tid`, `uid`, `description`, `start_date`, `end_date`, `status`, `filename`, `filesize`, `filetype`, `upload_date`) VALUES
(36, 8, ' sdskn', '2024-03-29', '2024-03-30', 'Completed', '204.jpg', 90856, 'image/jpeg', '2024-04-02 07:19:10'),
(37, 8, 'I am busy right now', '2024-04-04', '2024-04-06', 'Not Started', '204.jpg', 90856, 'image/jpeg', '2024-03-30 07:41:39'),
(38, 8, 'yftiyt', '2024-03-30', '2024-03-31', 'Not Started', '204.jpg', 90856, 'image/jpeg', '2024-03-30 08:19:35'),
(39, 13, 'futfutfytf', '2024-04-03', '2024-04-04', 'Completed', '204 (2).jpg', 90856, 'image/jpeg', '2024-04-24 05:02:51'),
(40, 8, 'hgfihfd', '2024-04-25', '2024-04-26', 'Not Started', '204 (2) (2).jpg', 90856, 'image/jpeg', '2024-04-24 04:59:19');

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(225) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(225) NOT NULL,
  `user_type` varchar(225) NOT NULL DEFAULT 'user',
  `chatstatus` varchar(225) DEFAULT NULL COMMENT 'Offline now,Online'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `user_type`, `chatstatus`) VALUES
(1, 'Rakesh ', 'Rakesh@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'user', NULL),
(7, 'shubham', 'shubhamsharma123@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'admin', NULL),
(8, 'Anurag', 'anurag.l.yadav@slrtce.in', '202cb962ac59075b964b07152d234b70', 'user', NULL),
(9, 'Amit', 'amit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'admin', NULL),
(13, 'Vishal', 'vishal@gmail.com', '202cb962ac59075b964b07152d234b70', 'user', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `lid` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

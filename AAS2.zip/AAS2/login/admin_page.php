<?php
function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

@include 'config.php';
include('../include/connection.php');
session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login_form.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script type="text/javascript">
 
</script>
    <title>Add Task</title>
</head>
<body>
        <header class="nav" id="navbar">
           <div class="logo">
           <p>AssignAlert</p>
           </div>
             
           <div class="search-container">
        <input type="text" class="search-bar" placeholder="Search...">
        <i class="fa fa-search" aria-hidden="true"></i>
    </div>
            <nav>
                <ul class="nav__links">
                    <li><a href="createtask.php" id="createtask"><i class="fa fa-plus-circle" aria-hidden="true"></i>Add Task</a></li>
                    
                    <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Calender</a></li>

                    <li> <a>UserName:<?php echo $_SESSION['admin_name'] ?></a></li>
                </ul>
            </nav>
           
        </header>
    <div class="side-nav">
    <ul class="sidebar">
                    <li><a href="admin_page.php"><i class="fa fa-home" aria-hidden="true"><p>Home</p></i></a></li>
                    <li><a href="managetask.php"><i class="fa fa-inbox" aria-hidden="true"><p>Inbox</p></i></a></li>
                    <li style="text-align: center;"><a href="appl.php"><i class="fa fa-file-text-o" aria-hidden="true"> <span><p>Application</p></span></i></a></li>
                <li><a href="invite.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <p>Invite</p></a></li>
                    <li><a href="logout.php"><i  class="fa fa-sign-out"  aria-hidden="true"></i><p>Logout</p></a></li>
                </ul>
    </div>
    
    <div class="rightsidebar" id="rsidebar">
    <div class="createright">
        <h4>Task Enquiries:</h4>
        <form action="" method="GET">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <input type="date" name="date" value="<?php echo isset($_GET['date']) ? $_GET['date'] : ''; ?>" class="form-control">
                </div>
                <div class="col-md-3">
                    <select name="name" class="form-control">
                        <option value="">- Select User -</option>
                        <?php
                        $query = "SELECT id, name FROM user_form WHERE user_type = 'user'";
                        $query_run = mysqli_query($connection, $query);
                        if (mysqli_num_rows($query_run) > 0) {
                            while ($row = mysqli_fetch_assoc($query_run)) {
                                ?>
                                <option value="<?php echo $row['id']; ?>" <?php echo isset($_GET['name']) && $_GET['name'] == $row['id'] ? 'selected' : ''; ?>><?php echo $row['name']; ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-control">
                        <option value="">Select Status</option>
                        <option value="In-Progress" <?php echo isset($_GET['status']) && $_GET['status'] == 'In-Progress' ? 'selected' : ''; ?>>In-Progress</option>
                        <option value="Completed" <?php echo isset($_GET['status']) && $_GET['status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="Not Started" <?php echo isset($_GET['status']) && $_GET['status'] == 'Not Started' ? 'selected' : ''; ?>>Not Started</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <div class="d-flex justify-content-around">
                        <button type="Submit" class="btn btn-primary">Filter</button>
                        <a href="admin_page.php" class="btn btn-danger">Reset</a>
                    </div>
                </div>
            </div>
        </form>

        <br>

        <table class="table">
            <tr>
                <th>Task ID</th>
                <th>Description</th>
                <th>Start Date</th>
                <th>End date</th>
                <th>Status</th>
            </tr>
            <?php
            $query_run = null; // Initialize $query_run

            if (isset($_GET['date']) && $_GET['date'] != '') {
                $date = validate($_GET['date']);
                $query = "SELECT * FROM task WHERE start_date='$date'";
                $query_run = mysqli_query($connection, $query);
            } elseif (isset($_GET['status']) && $_GET['status'] != '') {
                $status = validate($_GET['status']);
                $query = "SELECT * FROM task WHERE status='$status'";
                $query_run = mysqli_query($connection, $query);
            } elseif (isset($_GET['name']) && $_GET['name'] != '') {
                $uid = validate($_GET['name']);
                $query = "SELECT * FROM task INNER JOIN user_form ON task.uid = user_form.id WHERE user_form.id='$uid'";
                $query_run = mysqli_query($connection, $query);
            } else {
                $query = "SELECT * FROM task";
                $query_run = mysqli_query($connection, $query);
            }

            // Check if $query_run is not null before fetching rows
            if ($query_run) {
                while ($row = mysqli_fetch_assoc($query_run)) {
                    ?>
                    <tr>
                        <td><?php echo $row['tid']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo $row['start_date']; ?></td>
                        <td><?php echo $row['end_date']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                    </tr>
                    <?php
                }
            } else {
                ?>
                <tr>
                    <td colspan="5">No tasks found.</td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>
</div>

  
    
       
</body>
</html> 
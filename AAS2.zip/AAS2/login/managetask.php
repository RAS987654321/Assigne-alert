<?php
include('../include/connection.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="styles.css">
<script type="text/javascript">
 
</script>
<style>
        /* Center the button */
        .center {
            top: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 10px /* Set the height of the container to 100% of the viewport height */
        }

        /* Button styles */
        .button {
            padding: 10px 20px; /* Example padding; adjust as needed */
            background-color: #007bff; /* Example background color */
            color: white; /* Example text color */
            text-decoration: none; /* Remove underline from the link */
            border-radius: 5px;
        }
    </style>
    <title>Admin Dashboard</title>
</head>
<body>
        <header class="nav" id="navbar">
           <div class="logo">
           <p>AssignAlert</p>
           </div>
             
           <div class="search-container">
        <input type="text" class="search-bar" placeholder="Search...">
        <i class="fa fa-search" aria-hidden="true"></i>
    </div>
            <nav>
                <ul class="nav__links">
                    <li><a href="createtask.php" id="createtask"><i class="fa fa-plus-circle" aria-hidden="true"></i>Add Task</a></li>
                    
                    <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Calander</a></li>

                    <li><a href="user_data_print.php"><i class="fa fa-print"aria-hidden="true"></i>Print</a></li>
                </ul>
            </nav>
           
        </header>
    <div class="side-nav">
    <ul class="sidebar">
                    <li><a href="admin_page.php"><i class="fa fa-home" aria-hidden="true"><p>Home</p></i></a></li>
                    <li><a href="managetask.php"><i class="fa fa-inbox" aria-hidden="true"><p>Inbox</p></i></a></li>
                    <li  style="text-align: center;"><a href="appl.php"><i class="fa fa-file-text-o" aria-hidden="true"> <p>Docs</p></i></a></li>
                    <li><a href="chat.php"><i class="fa fa-ellipsis-h" aria-hidden="true"> <p>Chat</p></i></a></li>
                    
              
                <li><a href="invite.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <p>Invite</p></a></li>
                    <li><a href="logout.php"><i  class="fa fa-sign-out"  aria-hidden="true"></i><p>Logout</p></a></li>
                </ul>
    </div>
  
   <div class="rightsidebar"id="rsidebar">
  
  
           <table class="table">
            <tr>
                <th>S.No</th>
                <th>Task ID</th>
                <th>Description</th>
                <th>Start Date</th>
                <th>End date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php
            $sno=1;
            $query= "select * from task";
            $query_run=mysqli_query($connection,$query);
            while($row=mysqli_fetch_assoc($query_run)){
            ?>
               <tr> <td><?php echo $sno;?></td>
                <td><?php echo $row['tid'];?></td>
                <td><?php echo $row['description'];?></td>
                <td><?php echo $row['start_date'];?></td>
                <td><?php echo $row['end_date'];?></td>
                <td><?php echo $row['status'];?></td>
                <td><a href="edit_task.php?id=<?php echo $row['tid']?>"type="button"class="btn btn-warning"style="text-decoration:none;color:black;">Edit</a> | 
                 <a href="delete_task.php?id=<?php echo $row['tid']?>" type="button"class="btn btn-warning"style="text-decoration:none;color:black;">Delete</a>
                </td>
            
            </tr>
                <?php
                $sno++;
            }
            ?>
           </table> 
   </div>
   
      

       
</body>
</html> 
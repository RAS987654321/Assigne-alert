<?php
    include('../include/connection.php');
    ?>
<!DOCTYPE html>
<html>
<head>
  <title> Print</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="print.css" media="print">
</head>
<body>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2>User Data</h2>
      <table class="table table-bordered print">
        
        <tbody>
        <tr>
                <th>S.No</th>
                <th>Task ID</th>
                <th>Description</th>
                <th>Start Date</th>
                <th>End date</th>
                <th>Status</th>
                
            </tr>
            <?php
            $sno=1;
            $query= "select * from task";
            $query_run=mysqli_query($connection,$query);
            while($row=mysqli_fetch_assoc($query_run)){
            ?>
               <tr> <td><?php echo $sno;?></td>
                <td><?php echo $row['tid'];?></td>
                <td><?php echo $row['description'];?></td>
                <td><?php echo $row['start_date'];?></td>
                <td><?php echo $row['end_date'];?></td>
                <td><?php echo $row['status'];?></td>
                
            
            </tr>
                <?php
                $sno++;
            }
            ?>
        </tbody>
      </table>

      <div class="text-center">
        <button onclick="window.print();" class="btn btn-primary" id="print-btn">Print</button>
      </div>
    </div>
  </div>
</div>
</body>
</html>































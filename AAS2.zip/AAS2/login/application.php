<?php
session_start();
@include 'config.php';
include('../include/connection.php');
if(isset($_POST['submit_leave'])){
    $query = "INSERT INTO leaves ( id,name, subject, message, astatus) VALUES ('{$_SESSION['id']}','{$_SESSION['name']}', '{$_POST['subject']}', '{$_POST['message']}','{$_POST['astatus']}' 'No Action')";
    $query_run = mysqli_query($connection, $query);
    if($query_run){
        echo"<script type='text/javascript'>
            alert('Leave application submitted successfully..');
            window.location.href='user_page.php';
            </script>";
    }
    else{
        echo"<script type='text/javascript'>
        alert('Error..Please try again... ');
        window.location.href='application.php';
        </script>";

    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>User Dashboard</title>
</head>
<body>
    <header class="nav" id="navbar">
        <div class="logo">
            <p>AssignAlert</p>
        </div>
        <div class="search-container">
            <input type="text" class="search-bar" placeholder="Search...">
            <i class="fa fa-search" aria-hidden="true"></i>
        </div>
        <nav>
            <ul class="nav__links">
                <li><a href="#"><i class="fa fa-sticky-note-o" aria-hidden="true"></i>Notification</a></li>
                <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Calender</a></li>
                <li><a> UserName:<span><?php echo $_SESSION['user_name'] ?></span></a></li>
            </ul>
        </nav>
    </header>
    <div class="side-nav">
        <ul class="sidebar">
            <li><a href="user_page.php"><i class="fa fa-home" aria-hidden="true"><p>Home</p></i></a></li>
            <li><a href="task.php"><i class="fa fa-inbox" aria-hidden="true"><p>Inbox</p></i></a></li>
            <li style="text-align: center;"><a href="application.php"><i class="fa fa-file-text-o" aria-hidden="true"> <p>Application</p></i></a></li>
            
            <li><a href="invite.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <p>Invite</p></a></li>
            <li><a href="logout.php"><i  class="fa fa-sign-out"  aria-hidden="true"></i><p>Logout</p></a></li>
        </ul>
    </div>
    <div class="rightsidebar">
        <div class="createright">
            <h3>Apply Leave</h3>
            <div class="row">
                <div class="col-md-6">
                    <form action="" method="post">
                        <div class="form-group">
                            <input type="text" class="from-control" name="subject" placeholder="Enter Subject..">
                        </div>
                        <div class="form-group">
                            <textarea name="message" cols="140" rows="10" class="form-control" placeholder="Type Message"></textarea>
                        </div>
                        <input type="submit" class="btn btn-warning" name="submit_leave" value="Submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

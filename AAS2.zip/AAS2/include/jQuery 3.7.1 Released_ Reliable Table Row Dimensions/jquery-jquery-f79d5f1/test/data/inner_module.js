QUnit.assert.ok( true, "evaluated: inner module with src" );
